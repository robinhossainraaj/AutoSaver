package com.rorax.file

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Thin wrapper over the Telegram Bot API. */
class TelegramClient(private val token: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    private fun endpoint(method: String) = "https://api.telegram.org/bot$token/$method"

    fun getMe(): Result<String> = try {
        val req = Request.Builder().url(endpoint("getMe")).build()
        client.newCall(req).execute().use { resp ->
            val json = JSONObject(resp.body?.string().orEmpty())
            if (json.optBoolean("ok")) Result.success(json.getJSONObject("result").optString("username", "bot"))
            else Result.failure(Exception(json.optString("description", "getMe failed")))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun sendMessage(chatId: String, text: String): Result<Unit> = try {
        val form = FormBody.Builder()
            .add("chat_id", chatId)
            .add("text", text.take(4000))
            .build()
        val req = Request.Builder().url(endpoint("sendMessage")).post(form).build()
        client.newCall(req).execute().use { resp ->
            val json = JSONObject(resp.body?.string().orEmpty())
            if (json.optBoolean("ok")) Result.success(Unit)
            else Result.failure(Exception(json.optString("description", "sendMessage failed")))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun sendDocument(chatId: String, file: File, caption: String): Result<Unit> = try {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart("caption", caption.take(1000))
            .addFormDataPart(
                "document", file.name,
                file.asRequestBody("application/octet-stream".toMediaType())
            )
            .build()
        val req = Request.Builder().url(endpoint("sendDocument")).post(body).build()
        client.newCall(req).execute().use { resp ->
            val json = JSONObject(resp.body?.string().orEmpty())
            if (json.optBoolean("ok")) Result.success(Unit)
            else Result.failure(Exception(json.optString("description", "upload failed")))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}

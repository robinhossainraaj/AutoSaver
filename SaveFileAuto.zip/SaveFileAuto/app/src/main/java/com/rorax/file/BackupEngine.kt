package com.rorax.file

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Walks configured folders and uploads new/changed files to Telegram. */
class BackupEngine(
    private val context: Context,
    private val log: (String) -> Unit,
    private val shouldStop: () -> Boolean = { false }
) {
    private val cfg = ConfigManager(context)

    suspend fun run() = withContext(Dispatchers.IO) {
        if (cfg.botToken.isBlank() || cfg.chatId.isBlank()) {
            log("ERROR: set bot token and chat ID first")
            return@withContext
        }

        val tg = TelegramClient(cfg.botToken)
        val me = tg.getMe()
        if (me.isFailure) {
            log("ERROR: bot token invalid — ${me.exceptionOrNull()?.message}")
            return@withContext
        }
        log("Bot connected: @${me.getOrNull()}")

        val maxBytes = cfg.maxMb * 1024L * 1024L
        val state = cfg.getState()
        var uploaded = 0
        var skipped = 0
        var failed = 0

        for (folderPath in cfg.folders) {
            val root = File(folderPath)
            if (!root.exists() || !root.isDirectory) {
                log("skip (not found): $folderPath")
                continue
            }

            val stack = ArrayDeque<File>()
            stack.add(root)
            while (stack.isNotEmpty() && !shouldStop()) {
                val dir = stack.removeFirst()
                val children = try { dir.listFiles() } catch (e: Exception) { null } ?: continue
                for (file in children) {
                    if (shouldStop()) break
                    if (file.isDirectory) {
                        stack.add(file)
                        continue
                    }
                    if (!file.isFile) continue

                    val size = try { file.length() } catch (e: Exception) { continue }
                    if (size > maxBytes) continue

                    val sig = "${file.absolutePath}:$size:${file.lastModified()}"
                    if (state.contains(sig)) {
                        skipped++
                        continue
                    }

                    log("uploading: ${file.absolutePath}")
                    val result = tg.sendDocument(cfg.chatId, file, "Backup: ${file.name}")
                    if (result.isSuccess) {
                        state.add(sig)
                        uploaded++
                        log("  ok: ${file.name}")
                    } else {
                        failed++
                        log("  FAILED: ${file.name} — ${result.exceptionOrNull()?.message}")
                    }
                }
            }
            cfg.saveState(state)
        }

        log("DONE: $uploaded uploaded, $skipped unchanged, $failed failed")
    }
}

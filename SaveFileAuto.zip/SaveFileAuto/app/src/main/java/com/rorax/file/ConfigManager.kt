package com.rorax.file

import android.content.Context
import androidx.core.content.edit

/** Stores user configuration and upload state in SharedPreferences. */
class ConfigManager(context: Context) {
    private val prefs = context.getSharedPreferences("sfa_config", Context.MODE_PRIVATE)

    var botToken: String
        get() = prefs.getString("bot_token", "") ?: ""
        set(value) = prefs.edit { putString("bot_token", value) }

    var chatId: String
        get() = prefs.getString("chat_id", "") ?: ""
        set(value) = prefs.edit { putString("chat_id", value) }

    var folders: List<String>
        get() = (prefs.getString("folders", "") ?: "")
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        set(value) = prefs.edit { putString("folders", value.joinToString("\n")) }

    var maxMb: Int
        get() = prefs.getInt("max_mb", 45)
        set(value) = prefs.edit { putInt("max_mb", value) }

    fun getState(): MutableSet<String> =
        HashSet(prefs.getStringSet("state", emptySet()) ?: emptySet())

    fun saveState(state: Set<String>) = prefs.edit { putStringSet("state", state) }

    companion object {
        const val DEFAULT_FOLDERS = "/sdcard/DCIM\n/sdcard/Pictures\n/sdcard/Download\n/sdcard/Documents\n/sdcard/Movies\n/sdcard/Music"
    }
}

package com.rorax.file

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tokenEdit: EditText
    private lateinit var chatEdit: EditText
    private lateinit var foldersEdit: EditText
    private lateinit var maxEdit: EditText
    private lateinit var logView: TextView
    private lateinit var scrollView: ScrollView

    private val cfg by lazy { ConfigManager(this) }

    private val logReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val msg = intent?.getStringExtra(BackupService.EXTRA_LOG) ?: return
            appendLog(msg)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tokenEdit = findViewById(R.id.tokenEdit)
        chatEdit = findViewById(R.id.chatEdit)
        foldersEdit = findViewById(R.id.foldersEdit)
        maxEdit = findViewById(R.id.maxEdit)
        logView = findViewById(R.id.logView)
        scrollView = findViewById(R.id.scrollView)

        tokenEdit.setText(cfg.botToken)
        chatEdit.setText(cfg.chatId)
        foldersEdit.setText(
            if (cfg.folders.isEmpty()) ConfigManager.DEFAULT_FOLDERS
            else cfg.folders.joinToString("\n")
        )
        maxEdit.setText(cfg.maxMb.toString())

        findViewById<Button>(R.id.grantBtn).setOnClickListener { requestAllFilesAccess() }
        findViewById<Button>(R.id.startBtn).setOnClickListener { startBackup() }
        findViewById<Button>(R.id.stopBtn).setOnClickListener { stopBackup() }
        findViewById<Button>(R.id.testBtn).setOnClickListener { testBot() }

        appendLog("Ready. Set your bot token and chat ID, grant file access, then press Start.")
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(BackupService.ACTION_LOG)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(logReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(logReceiver, filter)
        }
    }

    override fun onPause() {
        try { unregisterReceiver(logReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    private fun saveConfig() {
        cfg.botToken = tokenEdit.text.toString().trim()
        cfg.chatId = chatEdit.text.toString().trim()
        cfg.folders = foldersEdit.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        cfg.maxMb = maxEdit.text.toString().trim().toIntOrNull()?.coerceIn(1, 50) ?: 45
    }

    private fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    private fun requestAllFilesAccess() {
        if (hasAllFilesAccess()) {
            Toast.makeText(this, "All-files access already granted", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.data = Uri.parse("package:$packageName")
            try {
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun startBackup() {
        saveConfig()
        if (!hasAllFilesAccess()) {
            Toast.makeText(this, "Grant all-files access first", Toast.LENGTH_LONG).show()
            requestAllFilesAccess()
            return
        }
        ensureNotificationPermission()
        appendLog("Starting backup...")
        val intent = Intent(this, BackupService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopBackup() {
        val intent = Intent(this, BackupService::class.java).apply { action = BackupService.ACTION_STOP }
        startService(intent)
        appendLog("Stop requested.")
    }

    private fun testBot() {
        saveConfig()
        if (cfg.botToken.isBlank()) {
            Toast.makeText(this, "Enter bot token first", Toast.LENGTH_SHORT).show()
            return
        }
        Thread {
            val result = TelegramClient(cfg.botToken).getMe()
            runOnUiThread {
                if (result.isSuccess) {
                    appendLog("Bot OK: @${result.getOrNull()}")
                    TelegramClient(cfg.botToken).sendMessage(cfg.chatId, "Save File Auto test OK")
                } else {
                    appendLog("Bot ERROR: ${result.exceptionOrNull()?.message}")
                }
            }
        }.start()
    }

    private fun appendLog(msg: String) {
        logView.append("$msg\n")
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}

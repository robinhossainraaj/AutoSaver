# Save File Auto (Android app)

A personal file-backup app for **your own device and files**. You configure your
own Telegram bot token and chat ID, choose folders, and press Start. Every
action is shown in the on-screen log and a foreground-service notification.
Nothing runs automatically until you press Start.

Package: `com.rorax.file`

## Build (on a PC with Android Studio)

1. Copy the whole `SaveFileAuto` folder to your PC.
2. Open Android Studio → **Open** → select `SaveFileAuto`.
3. Let Gradle sync (it downloads dependencies — needs internet).
4. **Build → Generate Signed Bundle / APK** (or just run on a device with the ▶ button).
5. Install the APK on your phone.

Requirements: Android Studio with Android SDK 35, JDK 17.

If Gradle complains about a missing wrapper JAR, let Android Studio regenerate it
(File → Sync Project with Gradle Files), or run `gradle wrapper` once.

## Build with GitHub Actions (no PC needed)

A workflow is included at `.github/workflows/build-apk.yml`. It builds the APK
in the cloud on every push.

1. Create a new repo on GitHub (e.g. `SaveFileAuto`).
2. Upload/push all files from this folder, including the `.github` folder.
3. Go to the repo → **Actions** tab → the *Build APK* workflow will run automatically.
4. When it finishes, open the run → scroll to **Artifacts** → download
   `SaveFileAuto-debug` → unzip to get `app-debug.apk`.
5. Install the APK on your phone (enable *Install unknown apps*).

You can also trigger a build manually with the **Run workflow** button in the Actions tab.

> Note: keep `config.json` / bot tokens out of the repo. The Android app stores
> the token locally on the device at runtime — no secret is in this source.

## Using the app

1. Enter your **bot token** and **chat ID**.
2. Press **Test Bot** — you should see "Bot OK: @username" and a test message in Telegram.
3. Press **Grant Access** — Android will open settings; enable *Allow access to all files*.
4. Edit the **folders** list (one path per line) if needed.
5. Press **Start Backup**. Progress shows in the log and notification.
6. Press **Stop** anytime. Re-running skips already-uploaded files.

## Notes

- Uses `MANAGE_EXTERNAL_STORAGE` — Google Play requires a declaration for this permission; sideloading is fine.
- Max file size defaults to 45 MB (Telegram bot document limit is 50 MB).
- Upload state is stored in the app's private SharedPreferences.
- Only your configured bot receives files. No hidden background behavior.
